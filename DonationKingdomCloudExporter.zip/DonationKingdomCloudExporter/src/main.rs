use anyhow::{bail, Context, Result};
use rbx_dom_weak::{InstanceBuilder, WeakDom};
use std::env;
use std::fs::{self, File};
use std::io::{BufReader, BufWriter};
use std::path::Path;

fn is_script_class(class: &str) -> bool {
    matches!(class, "Script" | "LocalScript" | "ModuleScript" | "CoreScript")
}

// GUI objects, their layout/effect helpers, and legacy in-world dialogs.
// These are removed wherever they occur under Workspace.
fn is_ui_class(class: &str) -> bool {
    matches!(
        class,
        "ScreenGui"
            | "BillboardGui"
            | "SurfaceGui"
            | "AdGui"
            | "GuiMain"
            | "Frame"
            | "ScrollingFrame"
            | "CanvasGroup"
            | "TextLabel"
            | "TextButton"
            | "TextBox"
            | "ImageLabel"
            | "ImageButton"
            | "ViewportFrame"
            | "VideoFrame"
            | "UICorner"
            | "UIStroke"
            | "UIGradient"
            | "UIAspectRatioConstraint"
            | "UIScale"
            | "UISizeConstraint"
            | "UITextSizeConstraint"
            | "UIPadding"
            | "UIListLayout"
            | "UIGridLayout"
            | "UITableLayout"
            | "UIPageLayout"
            | "UIFlexItem"
            | "ProximityPrompt"
            | "Dialog"
            | "DialogChoice"
    )
}

fn is_pruned_class(class: &str) -> bool {
    is_script_class(class)
        || is_ui_class(class)
        || matches!(class, "Camera" | "Terrain" | "TerrainRegion")
}

fn read_count(dom: &WeakDom, root_ref: rbx_dom_weak::types::Ref) -> usize {
    // rbx_dom_weak::WeakDom::descendants_of includes the root itself.
    dom.descendants_of(root_ref).count().saturating_sub(1)
}

fn run(input_path: &str, output_path: &str, report_path: &str, dependencies_path: &str) -> Result<()> {
    let input_file_path = Path::new(input_path);
    if !input_file_path.is_file() {
        bail!("Input place file not found: {input_path}");
    }

    let input_bytes = fs::metadata(input_file_path)
        .with_context(|| format!("Cannot inspect input file: {input_path}"))?
        .len();
    if input_bytes == 0 {
        bail!("Input file is empty: {input_path}");
    }

    eprintln!("Reading Roblox binary place: {input_path} ({input_bytes} bytes)");
    let input = BufReader::new(File::open(input_file_path)?);
    let source = rbx_binary::from_reader(input)
        .with_context(|| "rbx-dom could not parse the uploaded .rbxl file")?;

    let workspace_ref = source
        .descendants()
        .find(|instance| instance.class.as_str() == "Workspace")
        .map(|instance| instance.referent())
        .context("No Workspace instance was found in the place file")?;

    let workspace_descendants: Vec<_> = source
        .descendants_of(workspace_ref)
        .map(|instance| instance.referent())
        .collect();

    let source_instance_count = workspace_descendants.len().saturating_sub(1);
    let mut terrain_instances = 0usize;
    let mut terrain_region_instances = 0usize;
    let mut source_script_instances = 0usize;
    let mut source_ui_instances = 0usize;
    let mut source_mesh_parts = 0usize;
    let mut source_surface_appearances = 0usize;

    for referent in &workspace_descendants {
        let instance = source
            .get_by_ref(*referent)
            .context("Workspace instance reference disappeared")?;
        let class = instance.class.as_str();
        if class == "Terrain" {
            terrain_instances += 1;
        }
        if class == "TerrainRegion" {
            terrain_region_instances += 1;
        }
        if is_script_class(class) {
            source_script_instances += 1;
        }
        if is_ui_class(class) {
            source_ui_instances += 1;
        }
        if class == "MeshPart" {
            source_mesh_parts += 1;
        }
        if class == "SurfaceAppearance" {
            source_surface_appearances += 1;
        }
    }

    // Export Workspace only. Lighting, ReplicatedStorage, ServerStorage,
    // StarterGui, StarterPlayer and other services are not map geometry.
    let workspace_children = source
        .get_by_ref(workspace_ref)
        .context("Workspace disappeared during parsing")?
        .children()
        .to_vec();

    let mut map_roots = Vec::new();
    let mut root_cameras_skipped = 0usize;
    let mut root_terrain_skipped = 0usize;
    let mut root_terrain_regions_skipped = 0usize;

    for referent in workspace_children {
        let instance = source
            .get_by_ref(referent)
            .context("A direct Workspace child disappeared during parsing")?;
        match instance.class.as_str() {
            "Camera" => root_cameras_skipped += 1,
            "Terrain" => root_terrain_skipped += 1,
            "TerrainRegion" => root_terrain_regions_skipped += 1,
            _ => map_roots.push(referent),
        }
    }

    if map_roots.is_empty() {
        bail!("Workspace has no non-camera/non-terrain roots to export.");
    }

    // Clone all top-level Workspace roots together so references between them
    // can be remapped. The new Model container does not move/scale the parts.
    let mut exported = WeakDom::new(InstanceBuilder::new("Model").with_name("Donation Kingdom Map"));
    let exported_root = exported.root_ref();
    let cloned_roots = source.clone_multiple_into_external(&map_roots, &mut exported);
    for cloned_root in cloned_roots {
        exported.transfer_within(cloned_root, exported_root);
    }

    // Remove the highest excluded nodes only. Destroying a parent recursively
    // removes its descendants and avoids duplicate/dangling delete attempts.
    let all_refs: Vec<_> = exported
        .descendants_of(exported_root)
        .map(|instance| instance.referent())
        .collect();

    let mut remove_roots = Vec::new();
    let mut scripts_removed = 0usize;
    let mut ui_nodes_removed = 0usize;
    let mut cameras_removed = 0usize;
    let mut terrain_nodes_removed = 0usize;

    for referent in all_refs {
        if referent == exported_root {
            continue;
        }

        let instance = exported
            .get_by_ref(referent)
            .context("Exported instance reference disappeared")?;
        let class = instance.class.as_str();
        if !is_pruned_class(class) {
            continue;
        }

        if is_script_class(class) {
            scripts_removed += 1;
        }
        if is_ui_class(class) {
            ui_nodes_removed += 1;
        }
        if class == "Camera" {
            cameras_removed += 1;
        }
        if class == "Terrain" || class == "TerrainRegion" {
            terrain_nodes_removed += 1;
        }

        let parent_is_excluded = exported
            .get_by_ref(instance.parent())
            .map(|parent| is_pruned_class(parent.class.as_str()))
            .unwrap_or(false);
        if !parent_is_excluded {
            remove_roots.push(referent);
        }
    }

    for referent in remove_roots {
        if exported.get_by_ref(referent).is_some() {
            exported.destroy(referent);
        }
    }

    let exported_instance_count = read_count(&exported, exported_root);
    if exported_instance_count == 0 {
        bail!("The cleaned map is empty after removing scripts/UI/cameras/terrain.");
    }

    let output_path = Path::new(output_path);
    if let Some(parent) = output_path.parent() {
        if !parent.as_os_str().is_empty() {
            fs::create_dir_all(parent)?;
        }
    }

    let output_file = BufWriter::new(
        File::create(output_path)
            .with_context(|| format!("Cannot create output model: {}", output_path.display()))?,
    );
    rbx_binary::to_writer(output_file, &exported, &[exported_root])
        .with_context(|| "Could not serialize the cleaned Model as .rbxm")?;

    let output_bytes = fs::metadata(output_path)?.len();
    if output_bytes == 0 {
        bail!("Exporter produced an empty .rbxm file.");
    }

    // Parse the newly written file again and validate the root and exclusions.
    let verify_file = BufReader::new(File::open(output_path)?);
    let verified = rbx_binary::from_reader(verify_file)
        .with_context(|| "Generated .rbxm could not be parsed again")?;
    let top_level = verified.root().children();
    if top_level.len() != 1 {
        bail!(
            "Validation failed: expected exactly one top-level Model, found {}",
            top_level.len()
        );
    }

    let verified_root = top_level[0];
    let root_instance = verified
        .get_by_ref(verified_root)
        .context("Validation failed: exported root is missing")?;
    if root_instance.class.as_str() != "Model" {
        bail!("Validation failed: exported root is not a Model");
    }

    let mut mesh_parts = 0usize;
    let mut surface_appearances = 0usize;
    let mut decals_and_textures = 0usize;
    let mut dependency_lines = Vec::new();
    let mut validation_failures = Vec::new();

    for instance in verified.descendants_of(verified_root).skip(1) {
        let class = instance.class.as_str();
        if is_pruned_class(class) {
            validation_failures.push(format!(
                "{} at {}",
                class,
                verified.full_path_of(instance.referent(), ".")
            ));
        }
        match class {
            "MeshPart" => mesh_parts += 1,
            "SurfaceAppearance" => surface_appearances += 1,
            "Decal" | "Texture" => decals_and_textures += 1,
            _ => {}
        }

        let relevant_property_names = [
            "MeshId",
            "TextureID",
            "Texture",
            "Image",
            "ColorMap",
            "NormalMap",
            "RoughnessMap",
            "MetalnessMap",
            "ColorMapContent",
            "NormalMapContent",
            "RoughnessMapContent",
            "MetalnessMapContent",
        ];
        for (property_name, property_value) in &instance.properties {
            if relevant_property_names.contains(&property_name.as_str()) {
                dependency_lines.push(format!(
                    "{} [{}].{} = {:?}",
                    verified.full_path_of(instance.referent(), "."),
                    class,
                    property_name,
                    property_value
                ));
            }
        }
    }

    if !validation_failures.is_empty() {
        bail!(
            "Validation failed; excluded instances remain: {}",
            validation_failures.join(", ")
        );
    }

    let report = format!(
        concat!(
            "Donation Kingdom map export report\n",
            "Source file: {input_path}\n",
            "Source bytes: {input_bytes}\n",
            "Workspace instances seen (excluding Workspace root): {source_instance_count}\n",
            "Map instances exported (excluding Model root): {exported_instance_count}\n",
            "Source scripts found under Workspace: {source_script_instances}\n",
            "Source UI/prompt instances found under Workspace: {source_ui_instances}\n",
            "Scripts removed: {scripts_removed}\n",
            "UI/prompt instances removed: {ui_nodes_removed}\n",
            "Cameras removed: {cameras_removed}\n",
            "Terrain instances seen: {terrain_instances}\n",
            "TerrainRegion instances seen: {terrain_region_instances}\n",
            "Terrain/TerrainRegion instances removed: {terrain_nodes_removed}\n",
            "Top-level cameras skipped: {root_cameras_skipped}\n",
            "Top-level Terrain skipped: {root_terrain_skipped}\n",
            "Top-level TerrainRegion skipped: {root_terrain_regions_skipped}\n",
            "MeshParts kept: {mesh_parts}\n",
            "SurfaceAppearances kept: {surface_appearances}\n",
            "Decal/Texture objects kept: {decals_and_textures}\n",
            "Exported model bytes: {output_bytes}\n",
            "Binary re-open validation: PASSED\n\n",
            "IMPORTANT LIMITATIONS\n",
            "- Only Workspace descendants were exported.\n",
            "- Lighting, Atmosphere, Sky, post-processing, and non-Workspace services were not exported.\n",
            "- Terrain and TerrainRegion were omitted. Terrain-based sections will be missing.\n",
            "- MeshId, TextureID, SurfaceAppearance maps, Decal.Texture and Texture.Texture values are preserved as references, not copied as new assets.\n",
            "- Referenced assets must be owned by you, Open Use, or otherwise permitted for the destination experience. See Dependencies.txt for known mesh/texture properties.\n",
            "- References to instances outside Workspace may be cleared when cloning the Workspace map.\n",
            "- Roblox warns that .rbxm/.rbxmx files edited outside Studio may fail to upload or function.\n",
            "- Successful binary re-open validation does not guarantee Roblox upload or in-Studio visual fidelity.\n"
        ),
        input_path = input_path,
        input_bytes = input_bytes,
        source_instance_count = source_instance_count,
        exported_instance_count = exported_instance_count,
        source_script_instances = source_script_instances,
        source_ui_instances = source_ui_instances,
        scripts_removed = scripts_removed,
        ui_nodes_removed = ui_nodes_removed,
        cameras_removed = cameras_removed,
        terrain_instances = terrain_instances,
        terrain_region_instances = terrain_region_instances,
        terrain_nodes_removed = terrain_nodes_removed,
        root_cameras_skipped = root_cameras_skipped,
        root_terrain_skipped = root_terrain_skipped,
        root_terrain_regions_skipped = root_terrain_regions_skipped,
        mesh_parts = mesh_parts,
        surface_appearances = surface_appearances,
        decals_and_textures = decals_and_textures,
        output_bytes = output_bytes,
    );

    fs::write(report_path, report)?;

    let dependencies_report = if dependency_lines.is_empty() {
        "No common mesh/texture asset-reference properties were found on exported instances. This does not prove that the model has no external dependencies.\n".to_string()
    } else {
        let mut text = format!(
            "Known external mesh/texture references found: {}\n\n",
            dependency_lines.len()
        );
        text.push_str(&dependency_lines.join("\n"));
        text.push('\n');
        text
    };
    fs::write(dependencies_path, dependencies_report)?;

    println!("Export complete: {}", output_path.display());
    println!("Instances exported: {exported_instance_count}");
    println!("Scripts removed: {scripts_removed}; UI/prompt instances removed: {ui_nodes_removed}");
    println!("Terrain instances seen and omitted: {}", terrain_instances + terrain_region_instances);
    println!("MeshParts kept: {mesh_parts}; SurfaceAppearances kept: {surface_appearances}");
    println!("Output size: {output_bytes} bytes");
    println!("Binary re-open validation: PASSED");
    Ok(())
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() != 5 {
        eprintln!("Usage: map-exporter <input.rbxl> <output.rbxm> <report.txt> <dependencies.txt>");
        std::process::exit(2);
    }

    if let Err(error) = run(&args[1], &args[2], &args[3], &args[4]) {
        eprintln!("ERROR: {error:#}");
        std::process::exit(1);
    }
}
